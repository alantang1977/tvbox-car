### 1. TVBox 开源项目  
- TVBox系列相关软件可自行网络下载，本项目不提供相关软件。  
- 本服务站源仅提供免费项目。
- 如有需求可以联系QQ52670576.

### 2. 承接阿里云原画定制。服务QQ52670576.定制项目属于收费项目。其他免费。
[欢迎大家加群一起交流学习分享---点击直接加入群](https://qm.qq.com/cgi-bin/qm/qr?k=CdsCdFmE9qO5dROu-mT_4PANEsp_VbkH&jump_from=webapi&authKey=uHbpJc785kr8fTzzPeK+aGxB/A6XC6rzUq/s0vYl1hs6BfgASso1qd3Xm7/S5yHK) 

### 3.本接口不再提供本地化。

